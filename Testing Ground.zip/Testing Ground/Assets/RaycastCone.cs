using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RaycastCone : MonoBehaviour
{
    [Range(0.01f, 30.0f)]
    public float lightRadius = 1; // Made it a narrow radius for accuracy

    [Range(2, 10)] // If below 2, will break the for loop code.
    public int raycastLayers = 4; // How many layers in the raycast you might want

    float rayNum; // Used to keep track of which ray you're on
    public float rayTotal = 40; // Used to specify a max amount of rays
    public float widthInDegrees = 360; // Used to specify what degree circle is needed, should probably stay at 360 most of the time
    public float sightDistance = 8; // How far out the raycast goes


    void FixedUpdate()
    {
        RaycastHit hit;

        Vector3 rayVector;

        for (float i = 1; i < raycastLayers; i++)
        {
            float tempRadius = lightRadius * (i / raycastLayers); // Ensures that the radius shrinks with each increment
            float tempRayTot = rayTotal / (i / raycastLayers); // Ensures that the raytotal shrinks in comparison to the radius

            for (rayNum = 0; rayNum <= tempRayTot; rayNum++)
            {
                float x = Mathf.Cos(GetRayRad(rayNum)) * tempRadius;
                float y = Mathf.Sin(GetRayRad(rayNum)) * tempRadius;
                rayVector = new Vector3(x, y, sightDistance);

                Physics.Raycast(transform.position, transform.TransformDirection(rayVector), out hit);
                Debug.DrawRay(transform.position, transform.TransformDirection(rayVector), Color.yellow);
            }
        }

    }


    private float GetRayRad(float rayN)
    {
        float rayDeg = (((rayN / rayTotal) * widthInDegrees) - (widthInDegrees / 2));
        float rayRad = rayDeg * (Mathf.PI / 180.0f);
        return rayRad;
    }
}
